const CACHE = "nayan-security-v4";

function scopeUrl(path) {
  return new URL(path, self.registration.scope).href;
}

self.addEventListener("install", (event) => {
  const files = ["", "index.html", "404.html", "css/styles.css", "js/app.js", "js/api.js", "js/data.js", "js/store.js", "js/icons.js", "manifest.webmanifest"];
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(files.map(scopeUrl)).catch(() => undefined)));
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  const scopePath = new URL(self.registration.scope).pathname;
  if (!url.pathname.startsWith(scopePath)) return;
  if (url.pathname.includes("/api/")) return;
  event.respondWith((async () => {
    try {
      const res = await fetch(req);
      if (res && res.ok && url.origin === location.origin) {
        const cache = await caches.open(CACHE);
        cache.put(req, res.clone());
      }
      return res;
    } catch (err) {
      const cached = await caches.match(req);
      if (cached) return cached;
      if (req.mode === "navigate") {
        const home = await caches.match(scopeUrl("index.html")) || await caches.match(scopeUrl(""));
        if (home) return home;
      }
      throw err;
    }
  })());
});
