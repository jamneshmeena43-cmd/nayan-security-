"""Copy the root index.html into static route folders for GitHub Pages.

GitHub Pages does not run this script. The generated files are part of the site.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "index.html"

STATIC = [
    "services", "shop", "shops", "professionals", "cart", "checkout", "orders",
    "profile", "support", "support/ticket", "auth", "about", "contact", "search",
    "book", "quote/request", "quote/sample", "terms", "privacy", "refund",
    "warranty", "amc", "admin", "admin/security", "orders/sample", "orders/sample-product",
]


def ids_from_module():
    import json
    import subprocess
    script = """
import { products, services, shops, professionals, packages } from "./js/data.js";
const out = {
  product: products.map((x) => x.id),
  services: services.map((x) => x.id),
  shops: shops.map((x) => x.id),
  professionals: professionals.map((x) => x.id),
  packages: packages.map((x) => x.id),
};
process.stdout.write(JSON.stringify(out));
"""
    raw = subprocess.check_output(["node", "--input-type=module", "-e", script], cwd=ROOT, text=True)
    return json.loads(raw)


def prefix_assets(html: str, depth: int) -> str:
    if depth <= 0:
        return html
    prefix = "../" * depth

    def repl(match):
        attr, quote, url = match.group(1), match.group(2), match.group(3)
        if url.startswith(("http://", "https://", "/", "#", "data:", "../", "mailto:")):
            return match.group(0)
        return f"{attr}={quote}{prefix}{url}{quote}"

    return re.sub(r"(href|src)=(\"|')([^\"']+)\2", repl, html)


def main():
    routes = list(STATIC)
    data = ids_from_module()
    routes += [f"product/{item}" for item in data["product"]]
    routes += [f"services/{item}" for item in data["services"]]
    routes += [f"shops/{item}" for item in data["shops"]]
    routes += [f"professionals/{item}" for item in data["professionals"]]
    routes += [f"packages/{item}" for item in data["packages"]]
    html = INDEX.read_text()
    for route in routes:
        folder = ROOT / route
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / "index.html"
        if target.resolve() == INDEX.resolve():
            continue
        target.write_text(prefix_assets(html, len(Path(route).parts)))
    print(f"wrote {len(routes)} route shells")


if __name__ == "__main__":
    main()
