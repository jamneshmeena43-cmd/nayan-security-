"""NAYAN SECURITY application package."""
