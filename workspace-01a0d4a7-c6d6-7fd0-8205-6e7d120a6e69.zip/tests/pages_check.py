"""Check the static site as a GitHub Pages project under /nayan-security/."""
import json
import os
import re
import threading
from pathlib import Path

from playwright.sync_api import sync_playwright

from pages_server import Handler, ROOT, ThreadingHTTPServer

PORT = 8092
BASE = f"http://127.0.0.1:{PORT}/nayan-security/"
ROOT_PATH = Path(ROOT)


def start():
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


def asset_audit():
    missing = []
    text_files = [ROOT_PATH / "index.html", ROOT_PATH / "404.html", ROOT_PATH / "css" / "styles.css", ROOT_PATH / "manifest.webmanifest"]
    text_files += list((ROOT_PATH / "js").glob("*.js"))
    refs = set()
    for path in text_files:
        text = path.read_text(errors="ignore")
        refs.update(re.findall(r'(?:href|src|url\()\s*["\']?([^"\')\s]+)', text))
    for ref in sorted(refs):
        if ref.startswith(("http://", "https://", "data:", "#", "mailto:", "tel:")):
            continue
        if ref.startswith("/api/") or ref.startswith("api/"):
            continue
        clean = ref.split("?", 1)[0].split("#", 1)[0]
        if clean.startswith("/"):
            if clean.startswith(("/css/", "/js/", "/images/", "/fonts/", "/icons/", "/manifest")):
                missing.append(f"root-absolute {clean} in source")
            continue
        if clean in {"", "./", "/"}:
            continue
        candidate = (path.parent if False else ROOT_PATH / clean.lstrip("./"))
        # css url(../fonts/x) is relative to css/, not root
    css = (ROOT_PATH / "css" / "styles.css").read_text()
    for rel in re.findall(r'url\(["\']?([^"\')]+)', css):
        target = (ROOT_PATH / "css" / rel).resolve()
        if not target.is_file():
            missing.append(f"css missing {rel}")
    for rel in ["css/styles.css", "js/app.js", "js/api.js", "js/data.js", "js/icons.js", "js/store.js",
                "icons/favicon.svg", "icons/favicon-32.png", "icons/apple-touch-icon.png",
                "icons/icon-192.png", "icons/icon-512.png", "icons/icon-maskable-512.png",
                "images/hero-camera.jpg", "fonts/Outfit.ttf", "fonts/Newsreader.ttf", "manifest.webmanifest"]:
        disk = ROOT_PATH / rel
        if not disk.is_file() or disk.name != Path(rel).name:
            missing.append(f"missing or case mismatch {rel}")
    secret_hits = []
    for path in text_files:
        blob = path.read_text(errors="ignore")
        for needle in ("RAZORPAY_KEY_SECRET", "PAYMENT_WEBHOOK_SECRET", "ADMIN_PASSWORD", "BEGIN PRIVATE KEY"):
            if needle in blob:
                secret_hits.append(f"{path.name}:{needle}")
    return missing, secret_hits


def overflow(page):
    return page.evaluate("() => document.documentElement.scrollWidth - document.documentElement.clientWidth")


def run_browser():
    results = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        for name, width in (("mobile", 390), ("desktop", 1440)):
            page = browser.new_page(viewport={"width": width, "height": 900})
            bad = []
            errors = []
            page.on("pageerror", lambda err: errors.append(str(err)))
            page.on("response", lambda res: bad.append(f"{res.status} {res.url}") if res.status >= 400 and "/api/" not in res.url and not res.url.rstrip("/").endswith("/missing-page") else None)
            page.goto(BASE, wait_until="domcontentloaded")
            page.wait_for_selector("h1")
            page.wait_for_timeout(700)
            hero = page.locator("img[alt*='security camera']").first
            loaded = hero.evaluate("img => img.complete && img.naturalWidth > 0")
            font = page.evaluate("() => getComputedStyle(document.body).fontFamily")
            home_overflow = overflow(page)
            page.locator("a[href$='/services']:visible").first.click()
            page.wait_for_timeout(400)
            services_url = page.url
            services_title = page.locator("h1").first.inner_text()
            page.goto(BASE + "services/", wait_until="domcontentloaded")
            page.wait_for_timeout(500)
            refresh_title = page.locator("h1").first.inner_text()
            page.goto(BASE + "product/dome-2mp/", wait_until="domcontentloaded")
            page.wait_for_timeout(500)
            product_title = page.locator("h1").first.inner_text()
            page.goto(BASE + "missing-page", wait_until="domcontentloaded")
            missing_text = page.locator("body").inner_text()
            page.screenshot(path=f"/tmp/pages-{name}.png")
            results.append({
                "viewport": name,
                "home_overflow": home_overflow,
                "hero_loaded": loaded,
                "font": font,
                "services_url": services_url,
                "services_title": services_title,
                "refresh_title": refresh_title,
                "product_title": product_title,
                "missing_is_ours": "Page not found" in missing_text and "File not found" not in missing_text,
                "missing_buttons": all(word in missing_text for word in ("Home", "Services", "Shop")),
                "page_errors": errors,
                "asset_failures": [url for url in bad if "/nayan-security/" not in url or url.endswith((".css", ".js", ".jpg", ".png", ".svg", ".ttf", ".webmanifest"))],
            })
            page.close()
        browser.close()
    return results


def main():
    missing, secrets = asset_audit()
    server = start()
    try:
        browser = run_browser()
    finally:
        server.shutdown()
    report = {"asset_problems": missing, "secrets": secrets, "browser": browser, "index_at_root": (ROOT_PATH / "index.html").is_file()}
    print(json.dumps(report, indent=2))
    failed = bool(missing or secrets)
    for row in browser:
        if row["home_overflow"] or not row["hero_loaded"] or not row["missing_is_ours"] or row["page_errors"] or row["asset_failures"]:
            failed = True
        if "CCTV services" not in row["refresh_title"] and "Services" not in row["refresh_title"]:
            failed = True
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
