"""Static host that mimics a GitHub Pages project site at /nayan-security/."""
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PREFIX = "/nayan-security"
TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".webmanifest": "application/manifest+json",
    ".txt": "text/plain; charset=utf-8",
    ".ttf": "font/ttf",
    ".xml": "application/xml",
}


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        raw = self.path.split("?", 1)[0]
        if raw == PREFIX:
            self.send_response(301)
            self.send_header("Location", PREFIX + "/")
            self.end_headers()
            return
        if not raw.startswith(PREFIX + "/") and raw != PREFIX + "/":
            self.send_error(404, "File not found")
            return
        rel = raw[len(PREFIX):].lstrip("/")
        local = os.path.normpath(os.path.join(ROOT, rel))
        if not local.startswith(ROOT):
            self.send_error(404, "File not found")
            return
        if rel == "" or raw.endswith("/"):
            candidate = os.path.join(local, "index.html") if rel else os.path.join(ROOT, "index.html")
            if os.path.isfile(candidate):
                self._send(candidate, 200)
                return
        if os.path.isdir(local):
            self.send_response(301)
            self.send_header("Location", PREFIX + "/" + rel + "/")
            self.end_headers()
            return
        if os.path.isfile(local):
            self._send(local, 200)
            return
        self._send(os.path.join(ROOT, "404.html"), 404)

    def _send(self, path, status):
        with open(path, "rb") as handle:
            data = handle.read()
        ext = os.path.splitext(path)[1].lower()
        self.send_response(status)
        self.send_header("Content-Type", TYPES.get(ext, "application/octet-stream"))
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        return


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8092"))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"pages-sim on http://0.0.0.0:{port}{PREFIX}/", flush=True)
    server.serve_forever()
